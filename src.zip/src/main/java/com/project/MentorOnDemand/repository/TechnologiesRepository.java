package com.project.MentorOnDemand.repository;

import java.util.List;

import com.project.MentorOnDemand.model.Technologies;

public interface TechnologiesRepository 
{
	List<Technologies> findById(long id);
	List<Technologies> findByName(String name);
}