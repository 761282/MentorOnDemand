package com.project.MentorOnDemand.repository;

public interface MentorRepository 
{

}
