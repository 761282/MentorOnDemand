package com.project.MentorOnDemand.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.MentorOnDemand.model.Trainings;

public interface TrainingRepository extends JpaRepository<Trainings, String>
{
	
}
