package com.project.MentorOnDemand.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.MentorOnDemand.model.Trainings;

public interface TrainingRepository extends JpaRepository<Trainings, String>
{
	List<Trainings> findById(long id);
	List<Trainings> findByStatus(String status);
	void deleteById(long id);
}
