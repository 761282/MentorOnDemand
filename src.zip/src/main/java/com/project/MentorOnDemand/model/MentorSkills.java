package com.project.MentorOnDemand.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="mentorskills")

public class MentorSkills
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	
	/*@Column(name="id")
	private int id;*/
	
	@Column(name="mid")
	private int mid;
	
	@Column(name="sid")
	private int sid;
	
	@Column(name="self-rating")
	private float rating;
	
	@Column(name="years-of-experience")
	private int exp;
	
	@Column(name="trainings-delivered")
	private int trainings;
	
	@Column(name="facilities-offered")
	private String facilities;

	public MentorSkills() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MentorSkills( int mid, int sid, float rating, int exp, int trainings, String facilities) {
		super();
		
		this.mid = mid;
		this.sid = sid;
		this.rating = rating;
		this.exp = exp;
		this.trainings = trainings;
		this.facilities = facilities;
	}

	public long getId() {
		return id;
	}

	

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public int getExp() {
		return exp;
	}

	public void setExp(int exp) {
		this.exp = exp;
	}

	public int getTrainings() {
		return trainings;
	}

	public void setTrainings(int trainings) {
		this.trainings = trainings;
	}

	public String getFacilities() {
		return facilities;
	}

	public void setFacilities(String facilities) {
		this.facilities = facilities;
	}

	@Override
	public String toString() {
		return "MentorSkills [id=" + id + ", mid=" + mid + ", sid=" + sid + ", rating=" + rating + ", exp=" + exp
				+ ", trainings=" + trainings + ", facilities=" + facilities + "]";
	}
	
	
	
}
