package com.project.MentorOnDemand.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
//import javax.validation.constraints.Email;

@Entity
@Table(name="admin")

public class Admin 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	
	@Column(name="username")
	private String uname;
	
	@Column(name="password")
	private String pwd;

	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Admin( String uname, String pwd) {
		super();
		//this.admid = admid;
		this.uname = uname;
		this.pwd = pwd;
	}

	public long getId() {
		return id;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	@Override
	public String toString() {
		return "Admin [id=" + id + ", uname=" + uname + ", pwd=" + pwd + "]";
	}
	
	
	
}
