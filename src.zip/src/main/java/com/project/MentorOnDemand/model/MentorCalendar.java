package com.project.MentorOnDemand.model;

import java.sql.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="mentorcalendar")

public class MentorCalendar
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	
	@Column(name="mid")
	private int mid;
	
	@Column(name="start_time")
	private String stime;
	
	@Column(name="end_time")
	private String etime;
	
	@Column(name="start_date")
	private Date sdate;
	
	@Column(name="end_date")
	private Date edate;

	public MentorCalendar() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MentorCalendar(int mid, String stime, String etime, Date sdate, Date edate) {
		super();
		
		this.mid = mid;
		this.stime = stime;
		this.etime = etime;
		this.sdate = sdate;
		this.edate = edate;
	}

	public long getId() {
		return id;
	}

	

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public String getStime() {
		return stime;
	}

	public void setStime(String stime) {
		this.stime = stime;
	}

	public String getEtime() {
		return etime;
	}

	public void setEtime(String etime) {
		this.etime = etime;
	}

	public Date getSdate() {
		return sdate;
	}

	public void setSdate(Date sdate) {
		this.sdate = sdate;
	}

	public Date getEdate() {
		return edate;
	}

	public void setEdate(Date edate) {
		this.edate = edate;
	}

	@Override
	public String toString() {
		return "MentorCalendar [id=" + id + ", mid=" + mid + ", stime=" + stime + ", etime=" + etime + ", sdate="
				+ sdate + ", edate=" + edate + "]";
	}
	
	
	
}

