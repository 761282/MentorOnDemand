package com.project.MentorOnDemand.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="payments")

public class Payments
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	
	/*@Column(name="payments_id")
	private int pid;*/
	
	@Column(name="mentor_id")
	private int mid;
	
	@Column(name="training_id")
	private int tid;
	
	@Column(name="txn_type")
	private String txn;
	
	@Column(name="amount")
	private int amt;
	
	@Column(name="datetime")
	private String dt;
	
	@Column(name="remarks")
	private String remarks;

	public Payments() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Payments( int mid, int tid, String txn, int amt, String dt, String remarks) {
		super();
		
		this.mid = mid;
		this.tid = tid;
		this.txn = txn;
		this.amt = amt;
		this.dt = dt;
		this.remarks = remarks;
	}

	public long getId() {
		return id;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public String getTxn() {
		return txn;
	}

	public void setTxn(String txn) {
		this.txn = txn;
	}

	public int getAmt() {
		return amt;
	}

	public void setAmt(int amt) {
		this.amt = amt;
	}

	public String getDt() {
		return dt;
	}

	public void setDt(String dt) {
		this.dt = dt;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "Payments [id=" + id + ", mid=" + mid + ", tid=" + tid + ", txn=" + txn + ", amt=" + amt
				+ ", dt=" + dt + ", remarks=" + remarks + "]";
	}
	
	
	
}

