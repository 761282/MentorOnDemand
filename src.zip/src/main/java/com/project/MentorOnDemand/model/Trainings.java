package com.project.MentorOnDemand.model;

import java.sql.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="trainings")

public class Trainings 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	
	/*@Column(name="training_id")
	private int tid;*/
	
	@Column(name="user_id")
	private int uid;
	
	@Column(name="mentor_id")
	private int mid;
	
	@Column(name="skill_id")
	private int sid;
	
	@Column(name="status")
	private boolean status;
	
	@Column(name="Rating")
	private float rating;
	
	
	@Column(name="progress")
	private String progress;
	
	@Column(name="start_time")
	private String stime;
	
	@Column(name="end_time")
	private String etime;
	
	@Column(name="start_date")
	private Date sdate;
	
	@Column(name="end_date")
	private Date edate;
	
	@Column(name="amount_received")
	private int amt;

	public Trainings() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Trainings( int uid, int mid, int sid, boolean status, float rating, String progress, String stime,
			String etime, Date sdate, Date edate, int amt) 
	{
		super();

		this.uid = uid;
		this.mid = mid;
		this.sid = sid;
		this.status = status;
		this.rating = rating;
		this.progress = progress;
		this.stime = stime;
		this.etime = etime;
		this.sdate = sdate;
		this.edate = edate;
		this.amt = amt;
	}



	public long getId() {
		return id;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public String getProgress() {
		return progress;
	}

	public void setProgress(String progress) {
		this.progress = progress;
	}

	public String getStime() {
		return stime;
	}

	public void setStime(String stime) {
		this.stime = stime;
	}

	public String getEtime() {
		return etime;
	}

	public void setEtime(String etime) {
		this.etime = etime;
	}

	public Date getSdate() {
		return sdate;
	}

	public void setSdate(Date sdate) {
		this.sdate = sdate;
	}

	public Date getEdate() {
		return edate;
	}

	public void setEdate(Date edate) {
		this.edate = edate;
	}

	public int getAmt() {
		return amt;
	}

	public void setAmt(int amt) {
		this.amt = amt;
	}

	@Override
	public String toString() {
		return "Trainings [id=" + id + ", mid=" + mid + ", sid=" + sid + ", status=" + status
				+ ", rating=" + rating + ", progress=" + progress + ", stime=" + stime + ", etime=" + etime + ", sdate="
				+ sdate + ", edate=" + edate + ", amt=" + amt + "]";
	}
	
	
	
}
