package com.project.MentorOnDemand.model;

import java.sql.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
//import javax.print.DocFlavor.URL;
//import javax.validation.constraints.Email;

@Entity
@Table(name="mentor")

public class Mentor
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	
	/*@Column(name="mentor-id")
	private int mid;*/
	
	@Column(name="username")
	private String uname;
	
	@Column(name="linkedin-url")
	private  String link;
	
	@Column(name="reg-datetime")
	private Date regdate;
	
	@Column(name="reg-code")
	private  String mcode;
	
	@Column(name="years-of-experience")
	private int exp;
	
	@Column(name = "active")
	private boolean active;

	public Mentor() {
		//super();
	}

	public Mentor( String uname,  String link, Date regdate,  String mcode, int exp, boolean active) {
		//super();
		

		this.uname = uname;
		this.link = link;
		this.regdate = regdate;
		this.mcode = mcode;
		this.exp = exp;
		this.active = active;
	}

	public long getId() {
		return id;
	}



	

	public  String getUname() {
		return uname;
	}

	public void setUname( String uname) {
		this.uname = uname;
	}

	public  String getLink() {
		return link;
	}

	public void setLink( String link) {
		this.link = link;
	}

	public Date getRegdate() {
		return regdate;
	}

	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}

	public  String getMcode() {
		return mcode;
	}

	public void setMcode( String mcode) {
		this.mcode = mcode;
	}

	public int getExp() {
		return exp;
	}

	public void setExp(int exp) {
		this.exp = exp;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "Mentor [id=" + id + ", uname=" + uname + ", link=" + link + ", regdate=" + regdate
				+ ", mcode=" + mcode + ", exp=" + exp + ", active=" + active + "]";
	}
	
	
	
}
