package com.project.MentorOnDemand.model;

import java.sql.Date;
/*import java.util.Date;*/
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
//import javax.validation.constraints.Email;

@Entity
@Table(name = "user")

public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	/*@Column(name = "user-id")
	private int uid;*/
	
	@Column(name="username")
	private String uname;
	
	@Column(name="password")
	private String pwd;
	
	@Column(name="first-name")
	private String fname;
	
	@Column(name="last-name")
	private String lname;
	
	@Column(name="contact-number")
	private  long cno;
	
	@Column(name="reg-datetime")
	private Date regdate;
	
	@Column(name="reg-code")
	private String ucode;
	
	@Column(name = "active")
	private boolean active;

	public User() {
		
	}

	public User( String uname, String pwd, String fname, String lname,  long cno,  String ucode, boolean active) {
		
		this.uname = uname;
		this.pwd = pwd;
		this.fname = fname;
		this.lname = lname;
		this.cno = cno;
		this.ucode = ucode;
		this.active = active;
	}
	
	public long getId() {
		return id;
	}


	

	public  String getUname() {
		return uname;
	}

	public void setUname( String uname) {
		this.uname = uname;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public long getCno() {
		return cno;
	}

	public void setCno( long cno) {
		this.cno = cno;
	}

	public  String getUcode() {
		return ucode;
	}

	public void setUcode( String ucode) {
		this.ucode = ucode;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ",  uname=" + uname + ", pwd=" + pwd + ", fname=" + fname + ", lname="
				+ lname + ", cno=" + cno + ", regdate=" + regdate + ", ucode=" + ucode + ", active=" + active + "]";
	}

	
	
	
}
