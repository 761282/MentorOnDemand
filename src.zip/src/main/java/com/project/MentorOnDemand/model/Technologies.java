package com.project.MentorOnDemand.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="technologies")

public class Technologies 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	
	@Column(name="Name")
	private String name;
	
	@Column(name="TOC")
	private String toc;
	
	@Column(name="Duration")
	private int duration;
	
	@Column(name="pre-requites")
	private String req;

	public Technologies() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Technologies(String name, String toc, int duration, String req) {
		super();
		
		this.name = name;
		this.toc = toc;
		this.duration = duration;
		this.req = req;
	}

	public long getId() {
		return id;
	}

	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getToc() {
		return toc;
	}

	public void setToc(String toc) {
		this.toc = toc;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getReq() {
		return req;
	}

	public void setReq(String req) {
		this.req = req;
	}

	@Override
	public String toString() {
		return "Technologies [id=" + id + ", name=" + name + ", toc=" + toc + ", duration=" + duration + ", req=" + req
				+ "]";
	}
	
	
	
}

