package com.project.MentorOnDemand.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.project.MentorOnDemand.model.Trainings;
import com.project.MentorOnDemand.repository.TrainingRepository;

@RestController
@RequestMapping("/api")
public class TrainingController 
{
	@Autowired
	private TrainingRepository trainingrepo;
	
	@GetMapping("/trainings")
	public List<Trainings> getAllTrainings() {
		System.out.println("Get all Trainings...");

		List<Trainings> trainings = new ArrayList<>();
		trainingrepo.findAll().forEach(trainings::add);

		return trainings;
	}
	
	@GetMapping(value = "getTrainings/{id}")
	public List<Trainings> findById(@PathVariable long id) {

		List<Trainings> trainings = trainingrepo.findById(id);
		return trainings;
	}
	
	@GetMapping(value = "getTrainingsUnderProgress/{status}")
	public List<Trainings> findByStatus(@PathVariable String status) {

		List<Trainings> trainings = trainingrepo.findByStatus(status);
		return trainings;
	}
	
	@PostMapping(value = "/trainings/create")
	public Trainings postTrainings(@RequestBody Trainings training) {

		Trainings _customer = trainingrepo.save(new Trainings(training.getUid(),training.getMid(),training.getSid(),training.getRating(),training.getProgress(),training.getStatus(),training.getSdate(),training.getEdate(),training.getAmt(),training.getStime(),training.getEtime()));
		return _customer;
	}
	
	@DeleteMapping("/trainings/delete/{id}")
	public ResponseEntity<String> deleteTrainings(@PathVariable("id") long id) {
		System.out.println("Delete Trainings with ID = " + id + "...");

		trainingrepo.deleteById(id);

		return new ResponseEntity<>("Your Training has been deleted!", HttpStatus.OK);
	}
	
	@PostMapping
	@ResponseStatus(HttpStatus.OK)
		public void create(@RequestBody Trainings user)
		{
			trainingrepo.save(user);
		}
	
	@GetMapping("/{id}")
	public Trainings get(@PathVariable("id")String id)
	{
		return trainingrepo.getOne(id);
	}
	
}


