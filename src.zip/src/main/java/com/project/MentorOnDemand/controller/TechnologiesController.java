package com.project.MentorOnDemand.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.MentorOnDemand.model.Technologies;
import com.project.MentorOnDemand.repository.MentorSkillsRepository;
import com.project.MentorOnDemand.repository.TechnologiesRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class TechnologiesController
{
	@Autowired
	TechnologiesRepository technologyrepo;
	MentorSkillsRepository mentorskillsrepo;

	@GetMapping("/technologies")
	public List<Technologies> getAllSkills() {
		System.out.println("Get all Skills...");

		List<Technologies> technology = new ArrayList<>();
		technologyrepo.findAll().forEach(technology::add);

		return technology;
	}
	
	

	@GetMapping(value = "getTechnology/id/{id}")
	public List<Technologies> findById(@PathVariable long id) {

		List<Technologies> technologies = technologyrepo.findById(id);
		return technologies;
	}
	
	@GetMapping(value = "getSkill/name/{name}")
	public List<Technologies> findByName(@PathVariable String name) {

		List<Technologies> technology =technologyrepo.findByName(name);
		return technology;
	}
	
	
	
}
